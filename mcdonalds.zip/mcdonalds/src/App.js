import logo from './logo.svg';
import './App.css';

function App() {

  return (
    <div className="body">
      
    <div className="navbar">

    <div className="image"> <img src="https://img.freepik.com/premium-vector/dollar-bills-icons-set-currency-financial-security-exchange-banking-values-market-shares-money-concept-money-concept-vector-icon-set-white-background_661108-8059.jpg" width="100px"></img></div>

      <ul>
        <li><a>Our Menu</a></li>
        <li><a>Download App</a></li>
        <li><a>McDonald's Rewards</a></li>
        <li><a>Exclusive Deals</a></li>
        <li><a>About Our Food</a></li>
        <li><a>Locate</a></li>
        <li><a>Gift Cards</a></li>
        <li> <button>Order Now</button> </li>
      </ul>
    </div>

    <div className="article">

    <div className="art1"> <img src="https://www.mcdonalds.com/content/dam/sites/usa/nfl/publication/1pub_FreeBigMac_2336x1040.jpg" width="650px" ></img> </div>
    <div className="art1-text">

      <h1> Free Big Mac®. One for the Price of None.</h1>
      <h5>
      With $1 minimum purchase, score a free Big Mac after downloading the McD's app and joining MyMcDonald's Rewards.* Plus, with MyMcDonald’s Rewards, you’ll earn points to redeem for free food on every eligible order. Another Big Mac, maybe?
      </h5>
      <p>
      *Offer valid 1x thru the last day of the month for first time app users at participating McDonald's. May take up to 48 hours to appear in your deals. Must opt in to MyMcDonald’s Rewards. Excludes tax.
      </p>

      <button id="btn1">
        Get a Free BigMac
      </button>

    </div>

    </div>

    <div className="article">

    <div className="art1"> <img src="https://www.mcdonalds.com/content/dam/sites/usa/nfl/publication/1pub_McDeliveryintheApp_Launch_2336x1040_v3.jpg" width="650px" ></img> </div>
    <div className="art1-text">

      <h1>Get $0 Delivery Fee in the App</h1>
      <h5>
      Breakfast at the office? Late-night dinner moves? Get your faves delivered with $0 delivery fee on a $15+ order, only in the app. Plus, earn MyMcDonald’s Rewards points for free food on every order—and get them delivered, too. Check out how easy ordering delivery is in the app.*
      </h5>
      <p>
      *$15 minimum purchase required. Offer valid 1x/user from 9/12/23 thru 10/8/23 at participating McDonald's. Delivery prices may be higher than at restaurants. Must be opted into MyMcDonald's Rewards.
      </p>

      <button id="btn2">
        Get a Free BigMac
      </button>

    </div>

    </div>

    <div className="article">

    <div className="art1"> <img src="https://www.mcdonalds.com/content/dam/sites/usa/nfl/publication/1PUB_ROA_2336x1040v3.jpg" width="650px" ></img> </div>
    <div className="art1-text">

      <h1>New: Faster Faves, Only in the App</h1>
      <h5>
      We now prep when you’re on the way if you choose Curbside, Front Counter—or dine in for Table Service. Just order ahead in the app to save time. Because waiting in line for faves? Not our thing either.*
      </h5>
      <p>
      At participating McDonald’s.
      </p>

      <button id="btn3">
      Order Ahead in the App
      </button>

    </div>

    </div>


    <div className="article">

    <div className="art1"> <img src="https://www.mcdonalds.com/content/dam/sites/usa/nfl/publication/1PUB_Desktop_Deals-v1_1168x520.jpg" width="650px" ></img> </div>
    <div className="art1-text">

      <h1>Deals for Days</h1>
      <h5>
      Get exclusive deals on your McDonald’s favorites in the app with contactless Mobile Order & Pay* and convenient Drive Thru or Curbside pickup.
      </h5>
      <p>
      *Mobile Order & Pay at participating McDonald’s.
      </p>

      <button id="btn4">
      Get App Deals
      </button>

    </div>

    </div>
    

    <div className="lastbox">

      <div className="one">
        <ul>
        <h4>About Us</h4>
          <li>About Us Overview</li>
          <li>Leadership Team</li>
          <li>Values In Action</li>
          <li>Franchise Info</li>
          <li>Recalls & Alerts</li>
          <li>Real Estate</li>
          <li>Accessibility</li>
          <li>Investor Relations</li>
          <li>News & Notifications</li>
        </ul>
      </div>
      <div className="two">
        <ul>
        <h4>Services</h4>
          <li>Services Overview</li>
          <li>Wi-Fi</li>
          <li>PlayPlaces & Parties</li>
          <li>McDelivery®</li>
          <li>Mobile Order & Pay</li>
          <li>Trending Now</li>
          <li>McDonald’s Merchandise</li>
          <li>Family Fun Hub</li>
          <li>MyMcDonald's Rewards</li>
          <li>McCafé®</li>
        </ul>
      </div>
      <div className="three">
        <ul>
        <h4>Community</h4>
          <li>Community Overview</li>
          <li>Meet the 1 in 8</li>
          <li>HACER® Scholarships for Hispanic Students</li>
          <li>Ronald McDonald House Charities</li>
          <li>McDonald’s Asian Pacific American</li>
          <li>McDonald’s International</li>
          <li>Black and Positively Golden</li>
          <li>McDonald’s LGBTQ+</li>
        </ul>
      </div>
      <div className="four">
        <ul>
        <h4>Contact Us</h4>
          <li>Contact Us Overview</li>
          <li>Gift Card FAQs</li>
          <li>Donations</li>
          <li>Employment</li>
          <li>Customer Feedback</li>
          <li>Frequently Asked Questions</li>
          
        </ul>
      </div>

    </div>
    <h3>© 2017 - 2023 McDonald's. All Rights Reserved</h3>

    <div className="logo"> <img src="https://img.freepik.com/premium-vector/dollar-bills-icons-set-currency-financial-security-exchange-banking-values-market-shares-money-concept-money-concept-vector-icon-set-white-background_661108-8059.jpg" width="60px"></img></div>
    </div>
  );
}

export default App;
